package at.qe.sepm.asn_app.repositories;

import at.qe.sepm.asn_app.models.child.Child;

/**
 * Created by Emanuel Striednig <emanuel.striednig@student.uibk.ac.at>
 * on 20.03.2017.
 */
public interface ChildRepository extends AbstractRepository<Child, Long> {

}
