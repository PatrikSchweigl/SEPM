package at.qe.sepm.asn_app.models.referencePerson;

/**
 * Created by Stefan Mattersberger <stefan.mattersberger@student.uibk.ac.at>
 * on 19.03.2017
 */
public enum Relationship {
    AUNT_UNCLE,
    GRANDPARENT,
    FRIEND_OF_THE_FAMILY,
    SIBLING
}
