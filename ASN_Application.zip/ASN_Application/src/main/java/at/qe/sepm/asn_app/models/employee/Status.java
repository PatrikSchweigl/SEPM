package at.qe.sepm.asn_app.models.employee;

/**
 * Created by Stefan Mattersberger <stefan.mattersberger@student.uibk.ac.at>
 * on 20.03.2017
 */
public enum Status {
    PRESENT,
    ABSENT
}
