package at.qe.sepm.asn_app.models.ownExceptions;

/**
 * Created by root on 22.04.17.
 */
public class BirthdayConstraintException extends Exception {

    public BirthdayConstraintException(String message) {
        super(message);
    }

}
