package at.qe.sepm.asn_app.repositories;

import at.qe.sepm.asn_app.models.nursery.AuditLog;

/**
 * Created by Stefan Mattersberger <stefan.mattersberger@student.uibk.ac.at>
 * on 20.03.2017
 */
public interface AuditLogRepository extends AbstractRepository<AuditLog, Long>{
}
