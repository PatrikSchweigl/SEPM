package at.qe.sepm.asn_app.repositories;

/**
 * Created by Stefan Mattersberger <stefan.mattersberger@student.uibk.ac.at>
 * on 20.03.2017
 */
public interface NurseryInformationRepository {
}
