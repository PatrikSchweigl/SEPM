package at.qe.sepm.asn_app.models.general;

/**
 * Created by Stefan Mattersberger <stefan.mattersberger@student.uibk.ac.at>
 * on 19.03.2017
 */
public enum FamilyStatus {
    MARRIED,
    NOT_MARRIED,
    DIVORCED,
    WIDOWED,
    REGISTERED_PARTNERSHIP
}
